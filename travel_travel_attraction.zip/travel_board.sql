-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: travel
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `seqno` int NOT NULL AUTO_INCREMENT,
  `writer` varchar(32) NOT NULL,
  `title` text,
  `content` text,
  `hit` int DEFAULT '0',
  `created` char(32) DEFAULT NULL,
  `updated` char(32) DEFAULT NULL,
  `category` varchar(18) NOT NULL,
  `answer_count` int DEFAULT '0',
  PRIMARY KEY (`seqno`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (12,'asdf123','제주도 좋아요?','제주도 어때요??',63,'2023-12-12',NULL,'관광',1),(14,'tmakdlf1239@gmail.com','테스트테스트','ㄴㅁㅇㄹㅈㅈㄷㄻㅈㄷㄹㅈㄷㄻㄹㅈㄷㄹㅈㄷ',40,'2023-09-25 12:00:43','2023-09-25 12:00:43','음식점',2),(20,'tmakdlf1239@gmail.com','성공','성공',109,'2023-09-25 12:43:08','2023-09-25 14:30:29','관광',1),(23,'tmakdlf1239@gmail.com','조회수213','조회수123',26,'2023-09-25 13:58:32','2023-09-25 14:08:43','음식점',1),(24,'tmakdlf1239@gmail.com','ㅌㅅㅌ','ㅌㅅㅌ',60,'2023-09-25 15:55:24','2023-09-25 15:55:24','음식점',2),(27,'tmakdlf1239@gmail.com','제주도 말','말고기',18,'2023-09-26 10:39:12','2023-09-26 10:39:12','음식점',2),(28,'tmakdlf1239@gmail.com','제주도 물','물',13,'2023-09-26 10:39:23','2023-09-26 10:39:23','음식점',2),(36,'tmakdlf1239@gmail.com','카테고리 변경','수정',106,'2023-09-26 13:54:35','2023-09-26 15:02:12','음식점',1),(37,'tmakdlf1239@gmail.com','답변수','답변수답변수',3,'2023-09-26 15:05:53','2023-09-26 15:05:53','관광지',1),(38,'tmakdlf1239@gmail.com','답변수1','123123',94,'2023-09-26 15:06:37','2023-09-26 15:06:37','관광지',3),(39,'tmakdlf1239@gmail.com','123123','ㅁㅇㄴㄻㅇㄴㄹ',30,'2023-09-26 16:17:45','2023-09-26 16:17:45','음식점',1),(40,'tmakdlf1239@gmail.com','테스트트트','122121323',3,'2023-09-27 11:25:37','2023-09-27 11:25:37','기타',1);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-27 11:27:29
