-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: travel
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `foodstore`
--

DROP TABLE IF EXISTS `foodstore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `foodstore` (
  `fs_num` int NOT NULL AUTO_INCREMENT,
  `fs_name` varchar(32) NOT NULL,
  `fs_content` text,
  `fs_menu` varchar(16) NOT NULL,
  `fs_price` int NOT NULL,
  `fs_local` varchar(16) NOT NULL,
  `fs_img` varchar(128) DEFAULT NULL,
  `fs_address` varchar(32) DEFAULT NULL,
  `fs_cntNo` varchar(16) DEFAULT NULL,
  `fs_category` char(2) NOT NULL,
  PRIMARY KEY (`fs_num`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `foodstore`
--

LOCK TABLES `foodstore` WRITE;
/*!40000 ALTER TABLE `foodstore` DISABLE KEYS */;
INSERT INTO `foodstore` VALUES (1,'상춘재','2010년부터 영업을 시작한 상춘재는 항상 봄처럼이라는 뜻으로, 청와대의 귀빈들을 위한 식사대접 건물인 상춘재의 이름을 따왔다. 주방장님은 30년 경력의 쉐프로, 총 3번의 대통령을 모셨으며 제철 재료를 이용한 비빔밥과 돌솥밥들이 일품이다.','송키새우리 비빔밥',10000,'제주시 중앙로 598','상춘재.jpg','제주시 > 아라일동',NULL,'음식'),(2,'숙성도','숙성고기의 끝, 차원이 다른 숙성고기의 맛! \r\n제주 숙성도 (노형점 / 중문점) 입니다. \r\n \r\n제주 숙성도의 교차숙성된 흑돼지 고기는 지방의 풍미는 더하고 육질은 부드럽게 해 고기의 감칠맛을 극대화시켰습니다. \r\n오직 숙성도에서만 교차숙성 제주흑돼지고기로 품격 있는 숙성의 맛을 느껴보시기 바랍니다. 감사합니다.\r\n@단체안내@\r\n숙성도를 방문해주셔서 감사합니다.6인 이상 방문객분들은 매장이 협소하고 테이블 수가 적은 관계로 안내 받으실때 연결되지 않은 테이블로 배정받아 따로 앉으실 확률이 높습니다.\r\n대기등록 전에 참고해주시면 감사하겠습니다.','교차숙성흑돼지(살코기)',20000,'제주시 원노형로 41','숙성도.jpg','제주시 > 노형동',NULL,'음식'),(3,'미영이네','모슬포항앞에 위치한 고등어회, 방어회,여름에는 물회를 많이 드시러 오는 소박하지만 손맛 좋은 식당입니다.\r\n특히 고등어회는 미영이네에서만 맛볼 수 있는 특제 야채양념장과 고등어회 그리고 원초가 좋은 김과 함께 드시면\r\n그 맛에 많은 분들이 반하시고 또 고등어회를 드시고 난 후 나오는 고등어탕때문에 고등어회를 드시는 분들도 계시답니다.\r\n친절하고 손맛좋은 사장님이 맛있고 싱싱한 고등어회와 방어회 그리고 각종 계절음식들을 선보이고 있으니 많이 와주세요\r\n','고등어회 (대) + 탕',85000,'서귀포시 하모항구로 42','미정이네.jpg','서귀포시 > 대정읍',NULL,'음식');
/*!40000 ALTER TABLE `foodstore` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-22 17:24:39
