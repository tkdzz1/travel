-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: travel
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `comment_id` int NOT NULL AUTO_INCREMENT,
  `board_seqno` int NOT NULL,
  `commenter` varchar(32) NOT NULL,
  `comment_content` text,
  `comment_created` char(32) DEFAULT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,31,'tmakdlf1239@gmail.com','ㅈㅁㄷㄹㅈㄷㄻ','2023-09-26 12:18:37'),(2,26,'tmakdlf1239@gmail.com','ㅈㅁㄹㄷㅈㄻㄷㅈㄹㄷㅁ','2023-09-26 12:26:49'),(3,29,'tmakdlf1239@gmail.com','ㅈㅁㄷㄹㅈㅁㄷㄹㅈㅁㄷㄹ','2023-09-26 12:26:57'),(14,34,'tmakdlf1239@gmail.com','asdffsdsfda','2023-09-26 13:54:03'),(15,33,'tmakdlf1239@gmail.com','afwesaewffawe','2023-09-26 13:54:10'),(18,28,'tmakdlf1239@gmail.com','ㅈㅁㄹㄷㅈㄹㄷ','2023-09-26 14:38:01'),(19,27,'tmakdlf1239@gmail.com','ㅁㄴㅇㄹ','2023-09-26 14:41:40'),(20,14,'tmakdlf1239@gmail.com','수정','2023-09-26 14:45:16'),(24,24,'tmakdlf1239@gmail.com','수정합니다','2023-09-26 14:54:10'),(27,38,'tmakdlf1239@gmail.com','댓글수','2023-09-26 15:36:59'),(28,38,'tmakdlf1239@gmail.com','댓글3','2023-09-26 15:37:03'),(29,38,'tmakdlf1239@gmail.com','댓글4','2023-09-26 15:37:09'),(30,10,'tmakdlf1239@gmail.com','123','2023-09-26 16:18:03'),(31,20,'tmakdlf1239@gmail.com','124421421421','2023-09-26 16:18:12'),(32,39,'tmakdlf1239@gmail.com','ㅅㄷ','2023-09-26 16:18:22'),(33,36,'tmakdlf1239@gmail.com','ㅛㄷ됴뇨ㅛ','2023-09-26 16:18:34'),(34,37,'tmakdlf1239@gmail.com','ㅁㅈㄷㄹㅈㅁㄷ','2023-09-26 16:18:40'),(35,28,'tmakdlf1239@gmail.com','1231','2023-09-26 16:18:46'),(36,27,'tmakdlf1239@gmail.com','142421412','2023-09-26 16:18:53'),(37,24,'tmakdlf1239@gmail.com','ㄹㅈㅁㄷㄹㅈㄷㅁㅁㅈㄹㄷㅈㅁㄷ','2023-09-26 16:18:58'),(38,23,'tmakdlf1239@gmail.com','ㄹㅈㅁㄷㅈㅁㄹㄷㄹㅈㅁㄷ','2023-09-26 16:19:03'),(39,14,'tmakdlf1239@gmail.com','123','2023-09-26 16:20:27'),(40,12,'tmakdlf1239@gmail.com','12421','2023-09-26 16:20:35'),(41,40,'tmakdlf1239@gmail.com','ㄷㅈㄴㄻㅁㄹㅈㄷㄹㅈㅁㄷ','2023-09-27 11:26:34');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-27 11:27:28
