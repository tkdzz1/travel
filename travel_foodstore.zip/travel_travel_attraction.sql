-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: travel
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `travel_attraction`
--

DROP TABLE IF EXISTS `travel_attraction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_attraction` (
  `ta_num` int NOT NULL AUTO_INCREMENT,
  `ta_name` varchar(32) NOT NULL,
  `ta_local` varchar(16) NOT NULL,
  `ta_img` varchar(128) DEFAULT NULL,
  `ta_address` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ta_category` char(3) NOT NULL,
  `ta_latitude` double NOT NULL,
  `ta_longitude` double NOT NULL,
  `ta_hit` int DEFAULT '0',
  `ta_like` int DEFAULT '0',
  `ta_add` varchar(5) DEFAULT NULL,
  `ta_nx` int DEFAULT NULL,
  `ta_ny` int DEFAULT NULL,
  PRIMARY KEY (`ta_num`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_attraction`
--

LOCK TABLES `travel_attraction` WRITE;
/*!40000 ALTER TABLE `travel_attraction` DISABLE KEYS */;
INSERT INTO `travel_attraction` VALUES (59,'우도(해양도립공원)','우도','075da16d-2b3b-4cce-845e-2275fb72863620231004160203.jpg','제주특별자치도 제주시 우도면 삼양고수물길 1','관광지',33.5172268,126.9540275,90,0,'제주시',53,38),(60,'성산일출봉 (UNESCO 세계자연유산)','성산','c80e912a-507c-451f-a0a7-735d198077b420231004160837.gif','제주특별자치도 서귀포시 성산읍 일출로 284-12','관광지',33.4621467,126.9364271,39,0,'서귀포시',52,33),(61,'사려니숲길','조천','0d14a5dd-e323-47a0-8b28-b1d22c30567f20231004161100.jpg','제주특별자치도 제주시 조천읍 교래리 산 137-1','관광지',33.4077104,126.642567,21,0,'제주시',53,38),(62,'카멜리아힐','안덕','76d64f2c-bf52-488e-9141-d87b025dfe6b20231004162220.jpg','제주특별자치도 서귀포시 안덕면 병악로 166','관광지',33.289027,126.370051,8,0,'서귀포시',52,33),(63,'협재해수욕장','한림','de0099a5-e172-4859-90ba-2fdd606e687d20231004162422.jpg','제주특별자치도 제주시 한림읍 한림로 329-10','관광지',33.3933683,126.239783,8,0,'제주시',53,38),(64,'봄날카페','애월','a340b081-b52d-4a43-b8f9-42c3fde5b85d20231005100552.jpg','제주특별자치도 제주시 애월읍 애월로1길 25','음식',33.4624965,126.309699,3,0,'제주시',53,38),(65,'명진전복','구좌','023ba823-b83c-456c-9027-1551e707086020231005102249.gif','제주특별자치도 제주시 구좌읍 해맞이해안로 1282','음식',33.5324229,126.850021,2,0,'제주시',53,38),(66,'제주김만복(만복이네김밥집)','제주시','f6a9bf2c-32ee-4836-bb50-896ffcd0b8bb20231005103530.jpg','제주특별자치도 제주시 오라로 41','음식',33.4971028,126.508491,3,0,'제주시',53,38),(67,'올래국수','제주시','ce210c6d-998d-4701-9a3f-b4139302954920231005103724.jpg','제주특별자치도 제주시 귀아랑길 24 (연동)','음식',33.491522,126.497311,8,0,'제주시',53,38),(68,'우진해장국','제주시','4300c924-f9bd-4513-817c-5edb411c968f20231005103819.jpg','제주특별자치도 제주시 서사로 11','음식',33.5115287,126.520098,2,0,'제주시',53,38),(69,'돈사돈','제주시','36e55e8c-3ab4-494d-be9f-ec7e0655b02f20231005103859.gif','제주특별자치도 제주시 우평로 19','음식',33.4789132,126.464032,1,0,'제주시',53,38),(70,'신라호텔 제주','중문','d0169b88-fc14-42ac-9cb5-57fdffc9026920231005104232.jpg','제주특별자치도 서귀포시 중문관광로 72번길 75','숙박',33.2474556,126.408893,7,0,'서귀포시',52,33),(71,'롯데호텔 제주','중문','9510f2d8-d6e9-4db8-90f7-01697be8c3dd20231005104441.jpg','제주특별자치도 서귀포시 중문관광로72번길 35','숙박',33.2483112,126.410594,6,0,'서귀포시',52,33),(72,'나미송 머무는 곳','애월','394d796a-ff4c-4ea9-9201-8753736bfcc720231005104557.jpg','제주특별자치도 제주시 애월읍 평화로 2476','숙박',33.4303429,126.417782,1,0,'제주시',53,38),(73,'해비치 호텔 앤 리조트','표선','14ac8f11-2e59-41e1-8564-a466085036ed20231005104711.jpg','제주특별자치도 서귀포시 표선면 민속해안로 537','숙박',33.3235675,126.844477,4,0,'서귀포시',52,33),(74,'캠핑트리펜션','애월','60ec7226-c729-4fb2-8394-f22c251293a920231005104756.jpg','제주특별자치도 제주시 애월읍 광상로 115','숙박',33.4466356,126.417985,3,0,'제주시',53,38),(75,'서귀포KAL호텔','서귀포시','30ba7348-764b-40fb-9718-a7cd525f9f5f20231005104850.jpg','제주특별자치도 서귀포시 칠십리로 242','숙박',33.2463903,126.581249,2,0,'서귀포시',52,33),(76,'서귀포 매일 올레시장','서귀포시','6181ec06-213f-4c63-a8e6-361dd5cadbce20231005105026.jpg','제주특별자치도 서귀포시 중앙로62번길 18','쇼핑',33.2501977,126.563686,3,0,'서귀포시',52,33),(77,'제주동문시장','제주시','9089c38f-6458-4c48-ae07-c2443e09b1ea20231005110306.jpg','제주특별자치도 제주시 관덕로14길 20','쇼핑',33.5116059,126.526071,0,0,'제주시',53,38),(78,'제주관광공사 중문면세점 (내국인)','중문','5b6cb6fc-6c23-4dd2-8938-a8042ac909fb20231005110504.jpg','제주특별자치도 서귀포시 중문관광로 224(중문동) 제주국제컨벤션센터 1F','쇼핑',33.2405991,126.423317,1,0,'서귀포시',52,33),(79,'제주민속오일시장','제주시','a964b04d-20fe-4cc5-8ddb-32300bed1e5b20231005110604.jpg','제주특별자치도 제주시 오일장서길 26','쇼핑',33.4966106,126.47436,0,0,'제주시',53,38),(80,'동문수산시장','제주시','cdeea0bb-fb55-4450-9120-9990300ef20a20231005110652.jpg','제주특별자치도 제주시 관덕로 64-1','쇼핑',33.5126975,126.526259,0,0,'제주시',53,38),(81,'샘스제주캔들','애월','d151d18f-6a1e-42bf-bb3d-982815ef06b020231005110733.jpg','제주특별자치도 제주시 애월읍 애월로1길 26-2','쇼핑',33.4625969,126.309924,1,0,'제주시',53,38),(92,'test1','123','3bff7a9b-f175-4178-92bc-b8f4bbdf713520231006160254.JPG','123','관광지',33.39351890547324,126.23865868849029,28,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `travel_attraction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06 17:12:01
