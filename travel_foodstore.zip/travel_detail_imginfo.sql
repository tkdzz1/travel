-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: travel
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `detail_imginfo`
--

DROP TABLE IF EXISTS `detail_imginfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_imginfo` (
  `detail_num` int NOT NULL AUTO_INCREMENT,
  `ta_name` varchar(32) NOT NULL,
  `ta_imginfo` text,
  `ta_content` text,
  PRIMARY KEY (`detail_num`),
  UNIQUE KEY `ta_name` (`ta_name`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_imginfo`
--

LOCK TABLES `detail_imginfo` WRITE;
/*!40000 ALTER TABLE `detail_imginfo` DISABLE KEYS */;
INSERT INTO `detail_imginfo` VALUES (32,'우도(해양도립공원)','',''),(33,'성산일출봉 (UNESCO 세계자연유산)','/','성산일출봉'),(34,'사려니숲길','/','사려니숲길'),(35,'카멜리아힐','/','카멜리아힐'),(36,'협재해수욕장','/','협재해수욕장'),(37,'봄날카페','/','봄날카페'),(38,'명진전복','/','명진전복'),(39,'제주김만복(만복이네김밥집)','/','제주김만복'),(40,'올래국수','/',''),(41,'우진해장국','/','우진해장국'),(42,'돈사돈','/','돈사돈'),(43,'신라호텔 제주','/','신라호텔제주'),(44,'롯데호텔 제주','/','롯데호텔 제주'),(45,'나미송 머무는 곳','/','나미송 머무는 곳'),(46,'해비치 호텔 앤 리조트','/','해비치 호텔 앤 리조트'),(47,'캠핑트리펜션','/','캠핑트리펜션'),(48,'서귀포KAL호텔','/','서귀포KAL호텔'),(49,'서귀포 매일 올레시장','/','서귀포 매일 올레시장'),(50,'제주동문시장','17bfed3b-74fd-4b55-8930-00f51fc324e620231005110306.jpg','제주동문시장'),(51,'제주관광공사 중문면세점 (내국인)','/','제주관광공사 중문면세점 (내국인)'),(52,'제주민속오일시장','/','제주민속오일시장'),(53,'동문수산시장','/','동문수산시장'),(54,'샘스제주캔들','/','샘스제주캔들'),(65,'test1','cccca573-c1a8-4163-b2ee-964f61137b7e20231006163513.JPG/ba556842-835a-455d-9985-072ecbf88ce620231006163556.JPG/ecc15cba-0781-4d8f-b972-4817e57cdb8420231006163556.JPG','우도는 소가 누워있는 모양을 닮았다고 해서 일찍부터 소섬 또는 쉐섬으로 불리웠다. 완만한 경사와 옥토,풍부한 어장,우도팔경 등 천혜의 자연조건을 갖춘 관광지로써 한해 약 200만 명의 관광객이 찾는 제주의 대표적인 부속섬이다.\r\n\r\n성산항과 종달항에서 우도가는 배를 탈 수 있는데 어디서 출발하든 15분 정도 소요된다. 섬의 길이는 3.8km,둘레는 17km. 쉬지 않고 걸으면 3~4시간 걸리는 거리지만,대부분의 관광객은 버스나 자전거,미니 전기차를 타고 유명한 관광지 위주로 돌아본다. \r\n\r\n검멀레해변이나 우도봉,홍조단괴해변,하고수동해변 등 유명한 관광지 1-2개를 둘러보고,카페나 음식점에서 휴식을 즐겨도 대략 3-4시간 정도 소요된다. 여유있게 우도를 즐기고 싶다면 오전 아침배를 타고 들어가 오후 배를 타고 나와 하루종일 우도에 머물러 보는것도 좋다. 단,기상에 따라 배 운항여부가 달라질수 있으니 우도 여행일정을 짜는데는 기상조건을 필히 확인해야한다.\r\n\r\n우도를 찾는 관광객은 홍조단괴해변,우도봉,검멀레 해변을 주로 찾는다. 홍조단괴해변은 산호해변으로도 불렸는데,백사장을 이룬 하얀 알갱이가 산호가 아닌 홍조류가 딱딱하게 굳어 알갱이처럼 부서지면서 만들어진 것이 밝혀지면서 홍조단괴해변으로 부르며,홍조류로 이뤄진 백사장은 세계에서 드물어 보호하고 있다. \r\n\r\n너른 백사장과 아름다운 바다색으로 유명한 하고수동해수욕장도 있다. 경사가 완만한 천진동 코스와 경치가 멋진검멀레 해안코스가 있으며,우도봉에 올라 우도의 전경을 바라볼 수도 있다. 자연 절경 이외에도 바다낚시,자전거 하이킹,잠수함과 유람선 등을 통해 여행의 재미를 더하고 있다. \r\n\r\n\r\n\r\n※ 우도 외부차량(렌터카,전세버스) 반입 제한 조치는 2025년 7월 31일까지로 연장되었다.\r\n(단,1~3급 장애인과 만 65세 이상 노약자,임산부,만 6세 미만의 영유아를 동반하는 경우와 우도에 숙박하는 관광객이 탄 렌터카는 반입 가능하다.),123/ㄴㅁㅇㅁㅇㄴㅁㅁㅇㄴ/213123213/4123214');
/*!40000 ALTER TABLE `detail_imginfo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06 17:12:01
